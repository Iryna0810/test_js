const a = 'Переменная "a" in script-1.js';
console.log(a);
const b = 'Переменная "b" in script-1.js';
console.log(b);