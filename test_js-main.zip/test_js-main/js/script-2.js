const a = 'Переменная "a" in script-2.js';
console.log(a);
const c = 'Переменная "c" in script-2.js';
console.log(c);